package br.com.cm.workshop.apicrud.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import br.com.cm.workshop.apicrud.models.Status;
import br.com.cm.workshop.apicrud.repository.StatusRepository;

@Service
public class StatusService {

    @Autowired
    private StatusRepository repository;

    public Status atualizaStatus(@PathVariable Long id, @RequestBody Status status) {
        return repository.getById(id);
    }
}
