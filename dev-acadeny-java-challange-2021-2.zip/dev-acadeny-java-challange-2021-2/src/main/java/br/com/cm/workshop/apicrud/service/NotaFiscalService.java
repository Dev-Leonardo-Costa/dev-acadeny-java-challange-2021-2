package br.com.cm.workshop.apicrud.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cm.workshop.apicrud.models.Item;
import br.com.cm.workshop.apicrud.models.NotaFiscal;
import br.com.cm.workshop.apicrud.repository.NotaFiscalRepository;

@Service
public class NotaFiscalService {

    @Autowired
    public NotaFiscalRepository repository;

    public List<NotaFiscal> listaTodasNFs() {
        return repository.findAll();
    }

    public NotaFiscal CriarNotaFiscal(NotaFiscal notaFiscal) {
        double soma = 0;
        for (Item item : notaFiscal.getItems()) {
            item.setValorTotal(item.getPrecoUnitario() * item.getQuantidade());
            soma += item.getValorTotal();
        }
        notaFiscal.setValorTotalProdutos(soma);
        notaFiscal.setValorTotal(notaFiscal.getValorTotalProdutos() + notaFiscal.getValorfrete());
        return repository.saveAndFlush(notaFiscal);
    }

    public Optional<NotaFiscal> findById(Long id) {
        return repository.findById(id);
    }

    public void atualizaNotaFiscal(Long id) {
        repository.deleteById(id);
    }

    public NotaFiscal atualizaNotaFiscal(Long id, NotaFiscal notaFiscal) {
        if (repository.existsById(id)) {
            if (id.equals(notaFiscal.getId())) {
                return repository.saveAndFlush(notaFiscal);
            } else
                throw new UnsupportedOperationException("Id informado é diferente do id da Nota Fiscal");
        } else
            throw new EntityNotFoundException("Bebida não encontrada");
    }
}
