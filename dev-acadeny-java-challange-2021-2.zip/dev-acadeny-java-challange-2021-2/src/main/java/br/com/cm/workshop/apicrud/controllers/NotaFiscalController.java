package br.com.cm.workshop.apicrud.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.cm.workshop.apicrud.models.NotaFiscal;

import br.com.cm.workshop.apicrud.service.NotaFiscalService;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Nota Fiscal")
@RestController
@RequestMapping(path = "/api/v1/notas-fiscais")
public class NotaFiscalController {

    @Autowired
    private NotaFiscalService service;

    @GetMapping
    public List<NotaFiscal> listaTodasNFs() {
        return service.listaTodasNFs();
    }

    @GetMapping("/{id}")
    public Optional<NotaFiscal> getById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public NotaFiscal CriarNotaFiscal(@RequestBody NotaFiscal notaFiscal) {
        return service.CriarNotaFiscal(notaFiscal);
    }

    @PutMapping("/{id}")
    public NotaFiscal atualiza(@PathVariable Long id, @RequestBody NotaFiscal notaFiscal) {
        return service.atualizaNotaFiscal(id, notaFiscal);
    }

    @DeleteMapping("/{id}")
    public void remove(@PathVariable Long id) {
        service.atualizaNotaFiscal(id);
    }

    @ExceptionHandler(UnsupportedOperationException.class)
    @ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
    public void unsupported() {
    }

    @ExceptionHandler(EntityNotFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public void notFound() {
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

}
