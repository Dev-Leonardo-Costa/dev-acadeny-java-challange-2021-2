package br.com.cm.workshop.apicrud.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum StatusNotaFiscalEnum {
    PENDENTE("Pendente"), EM_PROCESSAMENTO("Em_Processamento"), APROVADA("Aprovado"), COM_ERRO("Com_Erro"),
    CANCELADA("Cancelada");

    private final String status;

    /*
     * private StatusNotaFiscalEnum(String status) { this.status = status; }
     */
}
