package br.com.cm.workshop.apicrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
